package org.nttdata.retoalumno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class RetoalumnoApplication {

    public static void main(String[] args) {
        SpringApplication.run(RetoalumnoApplication.class, args);
    }

}
