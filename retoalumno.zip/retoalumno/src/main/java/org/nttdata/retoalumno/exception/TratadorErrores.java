package org.nttdata.retoalumno.exception;

import org.nttdata.retoalumno.utils.Constants;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class TratadorErrores {

    @ExceptionHandler(value = RuntimeException.class)
    public ResponseEntity<MensajeError> errorHandlerSinBody(RuntimeException e) {

        MensajeError mensajeError = new MensajeError();
        mensajeError.setCode(Constants.CODE400);

        if (e.getMessage().contains(Constants.DEFAULTMESSAGE)) {

            mensajeError.setMensaje(obtenerError(e.getMessage()));

        } else {

            mensajeError.setMensaje(e.getMessage());

        }

        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(mensajeError);

    }

    private String obtenerError(String error) {

        String mensajeError = null;
        int tamano = error.length();
        int inicio = error.indexOf(Constants.DEFAULTMESSAGE);
        String mensajeNuevo = error.substring(inicio, tamano);
        String[] mensajeSplit = mensajeNuevo.split(Constants.PUNTOCOMA);
        tamano = mensajeSplit[1].indexOf(Constants.CORCHETEDER);
        inicio = mensajeSplit[1].indexOf(Constants.CORCHETEIZ) + 1;
        mensajeError = mensajeSplit[1].substring(inicio, tamano);

        return mensajeError;

    }

}
