package org.nttdata.retoalumno.expose;

import java.util.UUID;
import javax.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.nttdata.retoalumno.model.Alumno;
import org.nttdata.retoalumno.service.AlumnoService;
import org.nttdata.retoalumno.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.net.URI;

@RestController
@RequestMapping(Constants.BASEPATH)
@Slf4j
public class AlumnoController {

    @Autowired
    AlumnoService alumnoService;

    @PostMapping(path = Constants.SAVE, consumes = Constants.APPLICATIONJSON, produces = Constants.APPLICATIONJSON)
    public Mono<ResponseEntity<Object>> crearAlumno(@Valid @RequestBody Alumno alumnoCreado) {

        UUID uuid = UUID.randomUUID();
        log.info(uuid + Constants.ESPACIO + alumnoCreado);

        return alumnoService.saveAlumno(alumnoCreado)
                .flatMap((Alumno a) -> Mono.just(
                        ResponseEntity.created(URI.create(Constants.SAVE.concat(a.getApellido())))
                                .contentType(MediaType.APPLICATION_JSON).body(Mono.empty())));

    }

    @GetMapping(path = Constants.OBTENERALUMNOS)
    public Mono<ResponseEntity<Flux<Alumno>>> listarAlumnoActivo() {

        UUID uuid = UUID.randomUUID();
        log.info(uuid + Constants.VACIO);
        return Mono.just(ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON)
                .body(alumnoService.findByState()));

    }

}
