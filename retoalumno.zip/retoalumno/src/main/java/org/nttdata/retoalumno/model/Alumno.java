package org.nttdata.retoalumno.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Alumno {

    @Min(value = 1, message = "el id debe ser mayor a 0")
    @Id
    private long id;
    @NotBlank(message = "nombre is mandatory")
    private String nombre;
    @NotBlank(message = "apellido is mandatory")
    private String apellido;
    @Size(min = 6, max = 8, message = "estado debe ser activo/inactivo")
    @NotBlank(message = "estado is mandatory")
    private String estado;
    @Min(value = 1, message = "la edad debe ser mayor a 0")
    private int edad;
}
