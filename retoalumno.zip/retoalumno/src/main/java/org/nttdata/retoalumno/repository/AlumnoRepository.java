package org.nttdata.retoalumno.repository;

import org.nttdata.retoalumno.model.Alumno;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface AlumnoRepository {

    Mono<Alumno> saveAlumno(Alumno alumno);

    Flux<Alumno> findByState();

}
