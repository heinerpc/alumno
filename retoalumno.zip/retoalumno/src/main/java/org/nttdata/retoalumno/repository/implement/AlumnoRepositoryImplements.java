package org.nttdata.retoalumno.repository.implement;

import java.util.List;
import java.util.ArrayList;
import org.nttdata.retoalumno.model.Alumno;
import org.nttdata.retoalumno.repository.AlumnoRepository;
import org.nttdata.retoalumno.utils.Constants;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class AlumnoRepositoryImplements implements AlumnoRepository {

    List<Alumno> listaAlumno = new ArrayList<>();

    @Override
    public Mono<Alumno> saveAlumno(Alumno alumno) {

        if (listaAlumno.stream().filter((Alumno a) -> a.getId() == alumno.getId()).findFirst()
                .isEmpty()) {

            listaAlumno.add(alumno);
            return Mono.just(alumno);

        } else {

            return Mono
                    .error(new RuntimeException("Alumno con ID:" + alumno.getId() + " ya existe"));

        }

    }

    @Override
    public Flux<Alumno> findByState() {

        List<Alumno> listaActiva = new ArrayList<>();
        listaAlumno.stream().filter(a -> a.getEstado().equals(Constants.ACTIVO))
                .forEach(listaActiva::add);

        return Flux.fromIterable(listaActiva);

    }

}
