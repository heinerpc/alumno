package org.nttdata.retoalumno.service;

import org.nttdata.retoalumno.model.Alumno;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface AlumnoService {

    Mono<Alumno> saveAlumno(Alumno alumno);

    Flux<Alumno> findByState();

}
