package org.nttdata.retoalumno.service;

import org.nttdata.retoalumno.model.Alumno;
import org.nttdata.retoalumno.repository.AlumnoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AlumnoServiceImplements implements AlumnoService {

    @Autowired
    private AlumnoRepository repository;

    @Override
    public Mono<Alumno> saveAlumno(Alumno alumno) {

        return repository.saveAlumno(alumno);

    }

    @Override
    public Flux<Alumno> findByState() {

        return repository.findByState();

    }

}
