package org.nttdata.retoalumno.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Constants {

    public static final String VACIO = "";
    public static final String ESPACIO = " ";
    public static final String SAVE = "/save";
    public static final String OBTENERALUMNOS = "/alumnos";
    public static final String APPLICATIONJSON = "application/json";
    public static final String BASEPATH = "/retoalumno/v1";
    public static final String DEFAULTMESSAGE = "default message";
    public static final String PUNTOCOMA = ";";
    public static final String CORCHETEIZ = "[";
    public static final String CORCHETEDER = "]";
    public static final String CODE400 = "400";
    public static final String ACTIVO = "activo";
}