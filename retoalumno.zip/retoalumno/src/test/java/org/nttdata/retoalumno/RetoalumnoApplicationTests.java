package org.nttdata.retoalumno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetoalumnoApplicationTests {

	@Test
	void contextLoads() {
	}

}
