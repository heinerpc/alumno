package org.nttdata.retoalumno.expose;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.nttdata.retoalumno.model.Alumno;
import org.nttdata.retoalumno.service.AlumnoService;
import org.nttdata.retoalumno.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest
@AutoConfigureWebTestClient(timeout = "2000000000")
@DisplayName("Reto Alumno - Pruebas Unitarias")
public class AlumnoControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private AlumnoService alumnoService;

    static List<Alumno> listaAlumno = new ArrayList<>();

    @BeforeAll
    public static void setUp() throws IOException {

        listaAlumno.add(Alumno.builder().id(1).nombre("Heiner").apellido("Paredes")
                .estado("activo").edad(18).build());
        listaAlumno.add(Alumno.builder().id(1).nombre("Pedro").apellido("Rodriguez")
                .estado("activo").edad(17).build());
        listaAlumno.add(Alumno.builder().id(1).nombre("Miguel").apellido("Sanchez")
                .estado("activo").edad(16).build());

    }

    @Nested
    @TestMethodOrder(OrderAnnotation.class)
    @DisplayName("Tests de la operación guardar")
    class GuardarAlumno {

        @Test
        @Order(1)
        @DisplayName("guardar alumno.- Flujo Ok")
        void alumnoOk() {

            Mockito.when(alumnoService.saveAlumno(Mockito.any(Alumno.class)))
                    .thenReturn(Mono.just(Alumno.builder().id(1).nombre("Miguel")
                            .apellido("Sanchez").estado("activo").edad(16).build()));

            webTestClient.post().uri(Constants.BASEPATH + Constants.SAVE)
                    .accept(MediaType.APPLICATION_JSON)
                    .bodyValue(Alumno.builder().id(1).nombre("Miguel").apellido("Sanchez")
                            .estado("activo").edad(16).build())
                    .exchange().expectStatus().isCreated();

        }
    }

    @Nested
    @TestMethodOrder(OrderAnnotation.class)
    @DisplayName("Tests de la operación 'Obtener Alumnos'")
    class ObtenerAlumno {

        @Test
        @Order(1)
        @DisplayName("obtener alumnos.- Flujo Ok")
        void listaAlumnos() {

            Mockito.when(alumnoService.findByState()).thenReturn(Flux.fromIterable(listaAlumno));

            webTestClient.get().uri(Constants.BASEPATH + Constants.OBTENERALUMNOS).exchange()
                    .expectStatus().isOk().expectHeader().contentType(MediaType.APPLICATION_JSON)
                    .expectBodyList(Alumno.class);

        }
    }

}
