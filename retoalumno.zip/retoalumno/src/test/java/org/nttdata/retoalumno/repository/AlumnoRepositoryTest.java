package org.nttdata.retoalumno.repository;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.nttdata.retoalumno.model.Alumno;
import org.nttdata.retoalumno.repository.implement.AlumnoRepositoryImplements;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@SpringBootTest
@AutoConfigureWebTestClient
public class AlumnoRepositoryTest {

    @InjectMocks
    private AlumnoRepositoryImplements alumnoRepositoryImplements;

    static List<Alumno> listaAlumno = new ArrayList<>();
    Alumno alumnoPrueba = new Alumno();

    @BeforeEach
    public void setUp() {

        listaAlumno.add(Alumno.builder().id(1).nombre("Heiner").apellido("Paredes")
                .estado("activo").edad(18).build());
        listaAlumno.add(Alumno.builder().id(1).nombre("Pedro").apellido("Rodriguez")
                .estado("inactivo").edad(1).build());
        listaAlumno.add(Alumno.builder().id(1).nombre("Miguel").apellido("Sanchez")
                .estado("activo").edad(16).build());

        alumnoPrueba = Alumno.builder().id(1).nombre("Miguel").apellido("Sanchez").estado("activo")
                .edad(16).build();

    }

    @Test
    void save() {

        Mono<Alumno> resultado = alumnoRepositoryImplements.saveAlumno(alumnoPrueba);
        StepVerifier.create(resultado).equals(alumnoPrueba);
        assertNotNull(resultado);

    }

    @Test
    void findByState() {

        Flux<Alumno> resultado = alumnoRepositoryImplements.findByState();
        StepVerifier.create(resultado).equals(listaAlumno);
        assertNotNull(resultado);

    }

}
