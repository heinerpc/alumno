package org.nttdata.retoalumno.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.nttdata.retoalumno.model.Alumno;
import org.nttdata.retoalumno.repository.AlumnoRepository;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@SpringBootTest
@AutoConfigureWebTestClient
public class AlumnoServiceTest {

    @InjectMocks
    private AlumnoServiceImplements alumnoServiceImplements;

    @Mock
    private AlumnoRepository alumnoRepository;

    static List<Alumno> listaAlumno = new ArrayList<>();
    Alumno alumnoPrueba = new Alumno();

    @BeforeEach
    public void setUp() {

        listaAlumno.add(Alumno.builder().id(1).nombre("Heiner").apellido("Paredes")
                .estado("activo").edad(18).build());
        listaAlumno.add(Alumno.builder().id(1).nombre("Pedro").apellido("Rodriguez")
                .estado("activo").edad(17).build());
        listaAlumno.add(Alumno.builder().id(1).nombre("Miguel").apellido("Sanchez")
                .estado("activo").edad(16).build());

        alumnoPrueba = Alumno.builder().id(1).nombre("Miguel").apellido("Sanchez").estado("activo")
                .edad(16).build();

    }

    @Test
    void saveError() {

        Mockito.when(alumnoRepository.saveAlumno(Mockito.any(Alumno.class)))
                .thenReturn(Mono.just(alumnoPrueba));
        Mono<Alumno> resultado = alumnoServiceImplements.saveAlumno(alumnoPrueba);
        StepVerifier.create(resultado).equals(alumnoPrueba);
        assertNotNull(resultado);

    }

    @Test
    void findByState() {

        Mockito.when(alumnoRepository.findByState()).thenReturn(Flux.fromIterable(listaAlumno));
        Flux<Alumno> resultado = alumnoServiceImplements.findByState();
        StepVerifier.create(resultado).equals(listaAlumno);
        assertNotNull(resultado);

    }

}
